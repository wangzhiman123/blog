---
title: 江西省律师服务收费标准【附相关法律规定】
summary: "江西省律师服务收费的现行标准，附历年政策文件原文，方便对照报价是否合理。"
description: "江西省律师服务收费的现行标准，附历年政策文件原文，方便对照报价是否合理。"
date: 2026-10-03T10:00:00+08:00
categories:
- 工作
- 执业成长
tags:
- 律师费
- 江西南昌
- 资料下载
---

#

**目录**：

一、2003.07.01，江西省人民政府 政策文件 关于印发《江西省律师收费管理办法》和《江西省律师服务收费指导价标准（暂行）》的通知

二、2006.04.13，江西省人民政府 政策文件 律师服务收费管理办法

三、2021.07.12，关于征求《江西省律师服务收费指引（征求意见稿）》修改意见的通知

四、2022.03.07，转发《关于进一步规范律师服务收费的意见》的通知

五、资料来源

**一、2003.07.01，江西省人民政府 政策文件 关于印发《江西省律师收费管理办法》和《江西省律师服务收费指导价标准（暂行）》的通知**

![文章配图-1](https://q9.itc.cn/images01/20261010/09a1e3a3fd9a4387a8f525e937279d47.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-2](https://q5.itc.cn/images01/20261010/f6cd06430f2747c09c49e6aa06620561.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-3](https://q1.itc.cn/q_70/images06/20261010/433ff6f364a84b9ba54b0b093169325d.svg)

**二、2006.04.13，江西省人民政府 政策文件 律师服务收费管理办法**

![文章配图-1](https://q3.itc.cn/images01/20261010/bd47653e4047492cb593fca7354c4bc3.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-2](https://q1.itc.cn/images01/20261010/aa142cb70149456d847502cd2e7461dd.jpeg?x-oss-process=image/resize,w_1000/format,webp)

**三、2021.07.12，关于征求《江西省律师服务收费指引（征求意见稿）》修改意见的通知**

![文章配图-4](https://q7.itc.cn/images01/20261010/f54a356d26ba4ddfb8469da97cde1741.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-5](https://q5.itc.cn/images01/20261010/f31d5d19ff184d25b7d0341a63d73f6f.png?x-oss-process=image/resize,w_1000/format,webp)

**四、2022.03.07，转发《关于进一步规范律师服务收费的意见》的通知**

![文章配图-7](https://q8.itc.cn/images01/20261010/213ce4062b46460cb27ccb47275a676f.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-8](https://q5.itc.cn/images01/20261010/df1af7b031f04ffbb7b6e76422be618e.jpeg?x-oss-process=image/resize,w_1000/format,webp)

**五、资料来源：**

1.关于印发《江西省律师收费管理办法》和《江西省律师服务收费指导价标准（暂行）》的通知，成文日期:2003-07-01，来源：江西省人民政府官网，原始链接：<https://www.jiangxi.gov.cn/art/2008/4/29/art_5078_331032.html>

2.律师服务收费管理办法，成文日期:2006-04-13，来源：江西省人民政府官网，原始链接：<https://www.jiangxi.gov.cn/art/2008/4/29/art_5078_331028.html>

3.关于征求《江西省律师服务收费指引（征求意见稿）》修改意见的通知，成文日期:2021-07-12，文件链接：WPS云文档<https://kdocs.cn/l/cs2FvmJMuPWB>

4.转发《关于进一步规范律师服务收费的意见》的通知，成文日期:2022-03-07，文件链接：WPS云文档<https://kdocs.cn/l/cmknfHHijVVK>
