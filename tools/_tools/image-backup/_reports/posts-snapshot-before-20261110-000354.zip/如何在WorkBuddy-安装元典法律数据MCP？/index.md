---
title: 如何在WorkBuddy 安装元典法律数据MCP？
summary: "在 WorkBuddy 里装元典法律数据 MCP 的三步：拿 API Key、装连接器、验证是否真的通了。"
description: "在 WorkBuddy 里装元典法律数据 MCP 的三步：拿 API Key、装连接器、验证是否真的通了。"
date: 2026-10-28T00:00:00+08:00
categories:
- 工作
- 办案工具
tags:
- WorkBuddy
- 实务教程
---

最近，我经常使用腾讯的WorkBuddy进行法律文书初稿起草、类似案例检索等工作。但是，为了提高检索结果的准确性，还需要安装特定的法律数据库。现在，元典法律数据提供了一个接口，可以直接在WorkBuddy上安装使用。下面我将安装过程分享给大家。

## 第 1 步：去元典开放平台注册，拿到 API Key

1. 用浏览器打开[**法律AI API开放平台_元典开放平台**](https://open.chineselaw.com/),点右上角「注册 / 登录」，用手机号注册。
2. 登录后进入「个人中心」或「控制台」，找到**API Key**（有时叫「密钥」「令牌」），点「生成 / 创建」。
3. 复制那串字符（通常 sk- 开头），**先粘贴到记事本里存着**——页面刷新后可能就不再完整显示。

> 提醒一句：元典是**按积分计费**的，法条查询费积分少，案例检索（尤其语义检索）费得多。之前有个 4 月到 7 月的新站赠送活动，现在已经结束，你注册后先看一眼个人中心的积分余额，别默认有免费额度。

![image.png](https://q0.itc.cn/images01/20261029/ba4695f83c774b24bb9d4d8bfd53365c.png?x-oss-process=image/resize,w_1000/format,webp)

## 第 2 步：在 WorkBuddy 里装连接器（推荐，全程点鼠标）

WorkBuddy 的连接器市场里**已经有元典的官方连接器**，不用碰任何配置文件：

1. 看对话框**左下角的「+」号**，点开。
2. 选「**连接器**」（也有版本叫「插件 / 扩展」），在搜索框输入**元典**或**华宇**。
3. 找到「**华宇元典法律数据**」，点「连接 / 安装」。
4. 按提示把第 1 步复制的**API Key 粘贴进去**（或者如果你的电脑安装的是Windows11系统,它就会自动跳转到电脑浏览器的元典官方网站,因为前面你已经登录了元典网站账号,所以它就会直接显示 一键授权，直接点「授权」并在元典页面点同意,这样你连API Key都不用粘贴，就完成了操作,非常方便）。
5. 连接成功后，到「连接器管理」里确认它处于**已启用**状态。

![image.png](https://q1.itc.cn/images01/20261029/f788fb75af194616a4865d1d7fb571a4.png?x-oss-process=image/resize,w_1000/format,webp)

## 第2-1 步（备选）：如果第2步不行，就手填配置

这一步只有在第 2 步找不到时才需要。在「连接器」页点「**自定义连接器 / 配置 MCP**」，把下面这段粘进去，把 YOUR_API_KEY 换成你的 Key：

```
{
  "mcpServers": {
    "yuandian": {
      "url": "https://open.chineselaw.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

保存后**一定要去连接器列表里对新出现的`yuandian`点一下「信任」**，否则不会生效。然后完全退出 WorkBuddy 再重新打开。

## 第 3 步：验证是否真的通了

新开一个对话，直接问：

> 请通过元典 MCP 查询《民法典》第五百三十三条的全文，并注明来源。

- **通了的样子**：AI 会显示调用了 yuandian_... 工具，然后给出条文原文（情势变更条款）+「元典法律数据库」来源。
- **没通的样子**：AI 凭记忆直接背出来、或报错。对应关系是——401 Key 错了或没加 Bearer ；402 积分不足；429 调太快了；工具列表为空则重启客户端。

通了的样子:

![image.png](https://q9.itc.cn/images01/20261029/55ef2464620845a88eea3a38a19b13e3.png?x-oss-process=image/resize,w_1000/format,webp)

---

装好之后，两个让它更准的习惯

1. **明确下令「先查后答」**：每次提问都加上「请先调用元典检索再回答，不要凭记忆引用法条」。配了 MCP 它也可能偷懒先回忆，加这句话是行为指令，很管用。
2. **顺带装官配 Skill**：元典官方出了 prc-legal-research 技能包（open.chineselaw.com/mcp-config 页面可下载），作用是让 AI 自动判断该走法规、案例、企业还是证券合规，不用你记着点哪个工具。随着你使用越来越多，它会记住你的提问习惯和历史提问数据，在后面的回答中会越来越准确、专业。

![image.png](https://q2.itc.cn/images01/20261029/42fd45881718402e92c461be4337fb93.png?x-oss-process=image/resize,w_1000/format,webp)

![image.png](https://q0.itc.cn/images01/20261029/de0b35056873445fa0cf8a6b855cdadf.png?x-oss-process=image/resize,w_1000/format,webp)
