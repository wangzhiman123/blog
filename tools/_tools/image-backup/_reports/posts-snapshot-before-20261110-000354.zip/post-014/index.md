---
title: 【民事案例】淘宝店铺卖货侵权，积极应诉争取权益
summary: "淘宝店铺被诉著作权侵权、一审已败诉，代理被告方上诉的应诉思路，以及明知难赢为何还上诉。"
description: "淘宝店铺被诉著作权侵权、一审已败诉，代理被告方上诉的应诉思路，以及明知难赢为何还上诉。"
date: 2026-10-03T10:00:00+08:00
categories:
- 工作
- 案例复盘
tags:
- 案例复盘
- 知识产权
- 二审阶段
- 被告方
---

## 【民事案例】淘宝店铺卖货侵权，积极应诉争取权益

2026-10-08 22:18

发布于：江西省

该案是关于淘宝店铺侵犯著作权的知识产权类型案件，该案中我代理的是被告方。该案在一审已判决败诉的情况下，需要提起上诉。有时候即使知道胜诉的概率不大，但依然值得去试一试。我方在上诉过程中充分表达了我方观点，虽然最终还是被二审法院维持一审判决，但是依然达到了我方想要的诉讼的效果。判决书中关于个人及单位等的隐私信息已隐去（经过合法授权的除外），现分享如下，仅供学习交流。

![文章配图-1](https://q6.itc.cn/images01/20261008/1e2007a1b6744bbda972c6bc041a45c2.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-1](https://q5.itc.cn/images01/20261008/a4464afe45aa4566aaad2100cbd86a5e.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-2](https://q4.itc.cn/images01/20261008/f2b4fb23ae5e46c0b7cdb8f18ec1ea1d.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-3](https://q0.itc.cn/images01/20261008/baacce1064854c918e12d7f8dfe0ebbb.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-4](https://q5.itc.cn/images01/20261008/996370c33e09428fb3b9474ca7ea119a.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-5](https://q5.itc.cn/images01/20261008/521fe3fa63f9407384ac304d86c850d4.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-6](https://q6.itc.cn/images01/20261008/e1dfb1c58bf040328f0350771ff249f0.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-7](https://q9.itc.cn/images01/20261008/5ded9df1d2944e8199ee5aca8535cb25.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-8](https://q5.itc.cn/images01/20261008/77a12ba591b14443a9431050e285fcb1.jpeg?x-oss-process=image/resize,w_1000/format,webp)
