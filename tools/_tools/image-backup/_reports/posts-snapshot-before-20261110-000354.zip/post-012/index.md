---
title: 【最新模板下载】南昌市西湖区人民法院送达地址确认书、退费账号确认书
summary: "南昌西湖区法院立案要求的送达地址确认书、退费账号确认书专用模板，附空白文件下载。"
description: "南昌西湖区法院立案要求的送达地址确认书、退费账号确认书专用模板，附空白文件下载。"
date: 2026-10-03T10:00:00+08:00
categories:
- 工作
- 文书模板
tags:
- 资料下载
- 送达
---

简介：近期我在南昌西湖区法院提交立案的过程中，其中对于“送达地址确认书、退费账号确认书”2份材料，我提交的是通用模板（《人民法院送达地址送达方式确认书》模板、《退费账户确认书》模板），立案窗口的工作人员提醒下次最好使用南昌市西湖区法院的固定模板，故我将南昌市西湖区法院的最新文书模板进行如下更新，方便有需要的各位下载使用。

**一、南昌市西湖区人民法院送达地址确认书**

来源：南昌市西湖区人民法院诉讼服务中心立案窗口

文件来源时间：2025年7月31日

![文章配图-1](https://q8.itc.cn/images01/20261008/78c901daf48c4e62a3a5571d262ed2d8.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-1](https://q5.itc.cn/images01/20261008/62079c54512344c3abfafaa2838ee608.jpeg?x-oss-process=image/resize,w_1000/format,webp)

PDF文件下载链接：<https://kdocs.cn/l/cqGIwtWGALTK>

**二、南昌市西湖区人民法院退费账户确认书**

来源：南昌市西湖区人民法院诉讼服务中心立案窗口

文件来源时间：2025年7月31日

![文章配图-2](https://q5.itc.cn/images01/20261008/15097c054ab74e7d90fe7de22d2e2cf7.jpeg?x-oss-process=image/resize,w_1000/format,webp)

PDF文件下载链接：<https://kdocs.cn/l/clsXYGei16lt>
