---
title: 诉讼费缴纳异常问题解决记录
summary: "在律师服务平台缴诉讼费时提示登录信息丢失，反复重试失败，记录排查过程和最终解决步骤。"
description: "在律师服务平台缴诉讼费时提示登录信息丢失，反复重试失败，记录排查过程和最终解决步骤。"
date: 2026-09-30T02:29:00+08:00
categories:
- 工作
- 诉讼实务
tags:
- 诉讼费
- 立案
- 实务教程
---

![文章配图-1](https://q6.itc.cn/images01/20261007/a8534c9d7a6f4b9f9e441d4b26d23046.png?x-oss-process=image/resize,w_1000/format,webp)

**遇到的问题：**

在“人民法院律师服务平台”中，有一个案子遇到了无法正常缴纳山东省济南市天桥区人民法院案件一审诉讼费的情况，提示信息显示为“当前登录信息丢失，请重新登录”。

![文章配图-2](https://q7.itc.cn/images01/20261007/fdb03dacba8141a4a1d0a4d6e9ac5ef3.jpeg?x-oss-process=image/resize,w_1000/format,webp)

划到最下面，勾选缴费方式，并勾选使用说明后，也并未弹出“确定”“缴费”等类似按钮，导致无法通过人民法院律师服务平台进行缴纳诉讼费操作。

![文章配图-1](https://q5.itc.cn/images01/20261007/93b8bc1f509c4c1fb83d2b5b27e9240d.jpeg?x-oss-process=image/resize,w_1000/format,webp)

之前有一个案子在人民法院律师服务平台可以成功缴纳案子的诉讼费，当时并未出现这种情况。因为自收到缴纳诉讼费通知之日起7日内需要及时缴纳诉讼费，否则可能导致案件按自动撤诉处理的严重后果，那么如何解决现在遇到的这个问题呢？

**尝试的解决办法（含成功方案）：**

1、刷新网页，多次刷新网页，无法缴费。

2、关闭浏览器，重新登录，刷新网页，无法缴费。

3、将微软电脑操作系统自带的Edge浏览器切换成Internet Explorer 模式，重新登录，依然无法缴费。

4、更换成搜狗浏览器，重新登录，依然无法缴费。

5、使用手机浏览器，重新登录，依然无法缴费。

6、在电脑上打开山东法院电子诉讼服务网（网址：<https://www.sd12368.gov.cn/login>），选择“省外律师注册”，但是注册过程中显示我的身份证号码、手机号码、执业证号码均“已经注册过律师了”，但忘记密码时又显示“系统不存在该账号”，这样就陷入既无法注册又无法登录的矛盾悖论，依然无法缴费。

![文章配图-2](https://q6.itc.cn/images01/20261007/f354a7ac3f164a76b2f14ee68b1ed15a.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-3](https://q2.itc.cn/images01/20261007/f6104dfbe61b42c9a1b42f849c97beb6.jpeg?x-oss-process=image/resize,w_1000/format,webp)

7、通过“山东财政”微信公众号，在微服务〉非税缴费〉我要缴款〉按身份信息〉输入原告证件号码〉完成缴费！

![文章配图-4](https://q7.itc.cn/images01/20261007/1afee194485445659a4ffd4d3d628a3f.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-5](https://q6.itc.cn/images01/20261007/221631c53744484499796dacba17d2a0.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-6](https://q3.itc.cn/images01/20261007/bdf7f7b1ae4844d3a4fd30b38d4a3373.jpeg?x-oss-process=image/resize,w_1000/format,webp)

![文章配图-7](https://q8.itc.cn/images01/20261007/dea6feda2f7d4b81a4702244d26909af.jpeg?x-oss-process=image/resize,w_1000/format,webp)

后续手机上收到了一条短信，原来是关于诉讼费缴纳成功的电子发票的短信，根据短信信息就可以下载诉讼费电子发票，至此问题顺利解决！

![文章配图-8](https://q1.itc.cn/images01/20261007/eaa3c639eadd46f69ceac3faf9dbd9ea.jpeg?x-oss-process=image/resize,w_1000/format,webp)

> 本网站所载文章仅为一般性法律信息分享，不构成正式法律意见。

> 具体案件的处理需结合个案事实与证据判断，如您遇到法律问题，

> 请携带相关材料咨询执业律师。本网站内容不代表执业机构立场。
