---
title: 国产AI大模型Deepseek本地化部署教程（附所有下载资源）
summary: "在自己电脑上本地部署 DeepSeek 要什么配置、下哪些文件、怎么跑起来，附全部下载资源。"
description: "在自己电脑上本地部署 DeepSeek 要什么配置、下哪些文件、怎么跑起来，附全部下载资源。"
date: 2026-10-03T10:00:00+08:00
categories:
- 学习
- 工具教程
tags:
- AI 工具
- 实务教程
---

这几天国产人工智能AI对话大模型deepseek火了，它来自于一家名为“杭州深度求索人工智能基础技术研究有限公司”的中国公司。笔者作为一名律师，尝试了一下和该AI对话交流，它对于一些法律问题给出的回答确实令人惊艳。

![图片](https://q6.itc.cn/images01/20261008/bf6d9db7715446c0a7318c919bf652a2.jpeg?x-oss-process=image/resize,w_1000/format,webp)

图1 向deepseek-r1提问（部分）

![图片](https://q8.itc.cn/images01/20261008/d6f8fc75e14c4fe4a472dccae15c2385.jpeg?x-oss-process=image/resize,w_1000/format,webp)

图2 deepseek-r1的回答（部分）

因为deepseek官网（<https://www.deepseek.com/>）总是崩溃，而且deepseek手机端APP总是显示服务器异常无法使用，笔者决定尝试用电脑本地化部署deepseek，这样可以在保障基本的性能的情况下离线使用deepseek，经过一系列努力，笔者最终成功实现了这一想法。完整过程现分享如下，供和大家交流，另外下载资源也附在文末，供有需要的读者下载体验。

![图片](https://q1.itc.cn/images01/20261008/d0e119a0254a40a7bc382ecc091e269f.jpeg?x-oss-process=image/resize,w_1000/format,webp)

图3 deepseek-r1异常状态

**第一步**，获取ollama电脑软件，并进行安装。ollama官网地址：<https://ollama.com/>。

![图片](https://q3.itc.cn/images01/20261008/5ee6681062be44ee874b32056cf9c9ea.jpeg?x-oss-process=image/resize,w_1000/format,webp)

图4 ollama安装界面

**第二步**，使用ollama软件下载deepseek-r1模型。模型大小从1.5B到70B都有，需要根据电脑显卡性能进行选择，数字越大，效果越好，但对电脑显卡性能要求越高。例如：输入“ollama run deepseek-r1”，默认运行7b规模的deepseek-r1模型，第一次使用会先自动下载模型。输入“ollama run deepseek-r1:14b”，则会运行14b规模的deepseek-r1模型，第一次使用会先自动下载14b规模的deepseek-r1模型并运行。

![图片](https://q9.itc.cn/images01/20261008/024c4b045f564289ac9c5cb835c9991d.jpeg?x-oss-process=image/resize,w_1000/format,webp)

图5 deepseek-r1模型下载界面

**第三步**，根据电脑GPU性能下载适配的规模模型。例如笔者电脑为AMD RX6650xt（性能相当于NVIDIA RTX3060），笔者选择适配的是14b模型。经过笔者实测，AMD RX6650xt显卡运行32b模型非常缓慢，回答的速度非常迟缓，基本无法使用。

![图片](https://q4.itc.cn/images01/20261008/cf164323c5b44a57bbfd12ec13297660.jpeg?x-oss-process=image/resize,w_1000/format,webp)

图6 ollama官网deepseek模型下载界面

**第四步**，使用deepseek-r1模型。在终端管理员窗口输入“ollama run deepseek-r1:14b”,可以启动deepseek-r1 14b，然后输入问题即可得到回答。

![图片](https://q8.itc.cn/images01/20261008/62b57aed04be4381a01b950309f0bf4c.jpeg?x-oss-process=image/resize,w_1000/format,webp)

图7 deepseek模型安装完成及运行界面

在使用过程中，掌握一些简单的命令行输入指令，这样使用起来会更加高效好用。

![](https://q3.itc.cn/q_70/images06/20261008/1b2a509797054e8989194d2855dfae53.svg)

相关资源下载链接：

1、ollama电脑软件（Windows版）下载链接：<https://kdocs.cn/l/cmObcaDMcG7L>（说明：如果使用微信扫一扫，可能会跳转到金山文档小程序下载，因金山文档小程序最大支持100M压缩文件，从而导致保存失败。解决方法为：复制下载链接至浏览器中进行下载）
